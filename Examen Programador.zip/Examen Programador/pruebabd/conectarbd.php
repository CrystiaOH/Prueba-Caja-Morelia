<?php
$user = 'root'; // Usuario de MySQL
$pass = ''; // Nueva contraseña de MySQL
$server = 'localhost'; // Servidor MySQL
$bd = 'pruebabd'; // Nombre de la base de datos

$con = mysqli_connect($server, $user, $pass, $bd);

if (!$con) {
    die("Error de conexión a MySQL: " . mysqli_connect_error());
}
?>
