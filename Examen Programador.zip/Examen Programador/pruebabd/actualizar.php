<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Incluir archivo de conexión
    include('conectarbd.php');

    // Obtener el ID del registro a actualizar
    $id = intval($_GET['id']); 

    // Obtener los valores del formulario y escapar para prevenir SQL Injection
    $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
    $apellido_paterno = mysqli_real_escape_string($con, $_POST['apellido_paterno']);
    $apellido_materno = mysqli_real_escape_string($con, $_POST['apellido_materno']);
    $rfc = mysqli_real_escape_string($con, $_POST['rfc']);
    $curp = mysqli_real_escape_string($con, $_POST['curp']);
    $saldo_actual = mysqli_real_escape_string($con, $_POST['saldo_actual']);
    $fecha_contratacion = mysqli_real_escape_string($con, $_POST['fecha_contratacion']);
    $fecha_ultimo_movimiento = mysqli_real_escape_string($con, $_POST['fecha_ultimo_movimiento']);

    // Consulta SQL para actualizar el registro
    $sql = "UPDATE clientes SET 
                nombre='$nombre', 
                apellido_paterno='$apellido_paterno', 
                apellido_materno='$apellido_materno', 
                rfc='$rfc', 
                curp='$curp', 
                saldo_actual='$saldo_actual', 
                fecha_contratacion='$fecha_contratacion', 
                fecha_ultimo_movimiento='$fecha_ultimo_movimiento' 
            WHERE id=$id";
    
    // Ejecutar la consulta
    $result = mysqli_query($con, $sql);

    if ($result) {
        // Redirigir a la página de índice después de la actualización
        header('Location: index.php');
        exit();
    } else {
        // Mostrar mensaje de error en caso de fallo
        echo "Error al actualizar el registro: " . mysqli_error($con);
    }

    // Cerrar conexión
    mysqli_close($con);
}
?>

