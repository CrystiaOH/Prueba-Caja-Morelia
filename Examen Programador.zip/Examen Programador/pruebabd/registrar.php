<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $alert = '';
    
    // Conectar a la base de datos
    include('conectarbd.php');
    
    // Obtener y escapar valores
    $nombre = mysqli_real_escape_string($con, $_POST['nombre']);
    $apellido_paterno = mysqli_real_escape_string($con, $_POST['apellido_paterno']);
    $apellido_materno = mysqli_real_escape_string($con, $_POST['apellido_materno']);
    $rfc = mysqli_real_escape_string($con, $_POST['rfc']);
    $curp = mysqli_real_escape_string($con, $_POST['curp']);
    $saldo_actual = mysqli_real_escape_string($con, $_POST['saldo_actual']);
    $fecha_contratacion = mysqli_real_escape_string($con, $_POST['fecha_contratacion']);
    $fecha_ultimo_movimiento = mysqli_real_escape_string($con, $_POST['fecha_ultimo_movimiento']);

    // Consulta SQL
    $sql = "INSERT INTO clientes (nombre, apellido_paterno, apellido_materno, rfc, curp, saldo_actual, fecha_contratacion, fecha_ultimo_movimiento) 
            VALUES ('$nombre', '$apellido_paterno', '$apellido_materno', '$rfc', '$curp', '$saldo_actual', '$fecha_contratacion', '$fecha_ultimo_movimiento')";
    
    // Ejecutar consulta
    $resultado = mysqli_query($con, $sql);
    
    if ($resultado) {
        $alert = "<div class='alert alert-success content' role='alert'>
                    Registro agregado exitosamente
                  </div>";
    } else {
        $alert = "<div class='alert alert-danger content' role='alert'>
                    Registro no ingresado: " . mysqli_error($con) . "
                  </div>";
    }
    
    // Cerrar conexión
    mysqli_close($con);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <?php echo isset($alert) ? $alert : ''; ?>
    <form action="" method="post"> 
        <div class="mb-3" style="text-align: left;">
            <label>Nombre:</label>
            <input name="nombre" class="form-control" id="nombre">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>Apellido Paterno:</label>
            <input name="apellido_paterno" class="form-control" id="apellido_paterno">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>Apellido Materno:</label>
            <input name="apellido_materno" class="form-control" id="apellido_materno">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>RFC:</label>
            <input name="rfc" class="form-control" id="rfc">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>CURP:</label>
            <input name="curp" class="form-control" id="curp">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>Saldo Actual:</label>
            <input type="number" step="0.01" name="saldo_actual" class="form-control" id="saldo_actual">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>Fecha Contratacion:</label>
            <input type="date" name="fecha_contratacion" class="form-control" id="fecha_contratacion">
        </div>
        <div class="mb-3" style="text-align: left;">
            <label>Fecha Ult. Mov.:</label>
            <input type="date" name="fecha_ultimo_movimiento" class="form-control" id="fecha_ultimo_movimiento">
        </div>
        <div class="mb-3" style="text-align: left;">
            <input type="submit" name="submit" class="btn btn-success form-control" value="Registrar">    
        </div>
    </form>
</body>
</html>
