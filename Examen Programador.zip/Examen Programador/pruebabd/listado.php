<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado</title>
</head>
<body>
    <table id="customers">
        <tr>
            <th>Nº</th>
            <th>Nombre</th>
            <th>apellido_paterno</th>
            <th>apellido_materno</th>
            <th>rfc</th>
            <th>curp</th>
            <th>saldo_actual</th>
            <th>fecha_contratacion</th>
            <th>fecha_ultimo_movimiento</th>
            <th>Opciones</th>
        </tr>
        <?php
        include('conectarbd.php');

        // Consulta SQL
        $sql = "SELECT * FROM clientes";

        // Ejecutar la consulta
        $result = mysqli_query($con, $sql);

        // Verificar si la consulta se ejecutó correctamente
        if ($result === false) {
            echo "<tr><td colspan='6'>Error en la consulta: " . mysqli_error($con) . "</td></tr>";
        } else {
            // Procesar los resultados de la consulta
            while ($row = $result->fetch_assoc()) {
                $field0name = htmlspecialchars($row['id']);
                $field1name = htmlspecialchars($row['nombre']);
                $field2name = htmlspecialchars($row['apellido_paterno']);
                $field3name = htmlspecialchars($row['apellido_materno']);
                $field4name = htmlspecialchars($row['rfc']);
                $field5name = htmlspecialchars($row['curp']);
                $field6name = htmlspecialchars($row['saldo_actual']);
                $field7name = htmlspecialchars($row['fecha_contratacion']);
                $field8name = htmlspecialchars($row['fecha_ultimo_movimiento']);
                echo '<tr>
                    <td>' . $field0name . '</td>
                    <td>' . $field1name . '</td>
                    <td>' . $field2name . '</td>
                    <td>' . $field3name . '</td>
                    <td>' . $field4name . '</td>
                     <td>' . $field5name . '</td>
                    <td>' . $field6name . '</td>
                    <td>' . $field7name . '</td>
                    <td>' . $field8name . '</td>
                    <td>
                        <a href="eliminar.php?id=' . urlencode($field0name) . '" class="btn btn-danger">Eliminar</a>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop' . urlencode($row['id']) . '">Actualizar</button>
                    </td>
                </tr>';
            }
        }

        // Cerrar la conexión
        mysqli_close($con);
        ?>
    </table>
</body>
</html>
