<?php
 include('conectarbd.php');
 $id=$_GET['id'];
 $sql="delete from clientes where id='$id'";
 $result=mysqli_query($con,$sql);
 header('Location: index.php');
?>